#!/usr/bin/python
# -*- coding: utf-8 -*-

import requests
from requests import utils
from flask import Flask, request
import json
import time
import math
import random
import datetime
import boto3
from boto3.dynamodb.conditions import Key, Attr
from botocore.exceptions import ClientError
import random
import vision.vision as vision
import vision.visionAddress as visionAddress
import predict.predict as predict
import email_reply.email_reply as email_reply
#import googlemaps
#from datetime import datetime

#gmaps = googlemaps.Client(key='AIzaSyBI4ALNfd_6bVXSPG2h1Z-WxRbu0kuOWZs')
mydb = boto3.resource('dynamodb')  # we use dynamodb in AWS to record the status of every user so that the ChatBot is able to contiue the chat with them from time to time
tablevoiceone = mydb.Table('voiceone') # we use a table named 'voiceone' to do above works. sender id as the unique key.
tablereport = mydb.Table('bikereport') # this table is to save all report data from users.
tablereportbackup = mydb.Table('bikereportbackup') # this table is to save all report data from users.
tableusermessage = mydb.Table('usermessage') # this table is to save all report data from users.

# Token of the bot
with open('config.json', 'r') as f:  # this part is the same with any chatbot in the world
    config = json.load(f)
    print(config)
access_token = config['FACEBOOK']['ACCESS_TOKEN']
count=0

from pymessager.message import Messager, QuickReply, ContentType, ActionButton, ButtonType
client = Messager(config['FACEBOOK']['ACCESS_TOKEN'])

img_great = "https://scontent.fkhh1-1.fna.fbcdn.net/v/t1.0-9/67301384_913440575676029_1834425191191543808_n.jpg?_nc_cat=105&_nc_oc=AQkwa9UTmxgHH1Wxj5Sgdk649PIOhYQ2M3rc1m-QfF-dPJh2xLKS0oLJQlzT0y4pE98&_nc_ht=scontent.fkhh1-1.fna&oh=71ea7aee51a0eb4da8a00cf2d9e949b8&oe=5DB5B61F"
img_sorry = "https://scontent.fkhh1-2.fna.fbcdn.net/v/t1.0-9/67190049_913440499009370_1757733799887634432_n.jpg?_nc_cat=109&_nc_oc=AQlUW4PllPhv2KqBH-bbu5m4aGPf7XpNGdp4sEGJdXR-d973MmgLpQB6v-QucsuTPOo&_nc_ht=scontent.fkhh1-2.fna&oh=52fdd0400382fe0da67039af91adb66d&oe=5DAAD665"
img_cry = "https://scontent.fkhh1-1.fna.fbcdn.net/v/t1.0-9/67154157_913440442342709_5496511270666371072_n.jpg?_nc_cat=106&_nc_oc=AQkiX_rd_iHbutWLM3PWMgLeG_UBL2Ua7CoT2YVlTFg0HrKMAIt60kZn0taGKKPMJII&_nc_ht=scontent.fkhh1-1.fna&oh=2ff900deedb3c14e110f3ee0100b4534&oe=5DA6F958"
img_heihei = "https://scontent.fkhh1-2.fna.fbcdn.net/v/t1.0-9/67364028_913440522342701_3341716561831395328_n.jpg?_nc_cat=108&_nc_oc=AQkyupRc_LPEQAeOPfwGZ0uZi79HfupAfc-Z2JXXmi_St4C3VSge1eWLto8RWeCCxYQ&_nc_ht=scontent.fkhh1-2.fna&oh=db94f83af65c1019602cb57626660a7d&oe=5DE2F4C3"
img_letsgo = "https://scontent.fkhh1-2.fna.fbcdn.net/v/t1.0-9/67224808_913440449009375_2573876344605638656_n.jpg?_nc_cat=109&_nc_oc=AQmYxsoBCFa67E6509tiL0Aaw22muw97Qq4WJBectr0D1M2CvnC1mnKQNLvRxH7BLPs&_nc_ht=scontent.fkhh1-2.fna&oh=f9627d9b82b20223d2c95d8f37b14bf6&oe=5DA92467"
img_heart = "https://scontent.fkhh1-1.fna.fbcdn.net/v/t1.0-9/67402433_913440535676033_1568705241149341696_n.jpg?_nc_cat=101&_nc_oc=AQnj4QtcVcCEocFgz7w8v8ESMkHgUA8bIhJinEO5jV82KKEevNsaWKkgA2WpupCmMz4&_nc_ht=scontent.fkhh1-1.fna&oh=a6159795c70cc3d03bce450da8f1d68f&oe=5DA235D3"
img_stop = "https://scontent.fkhh1-1.fna.fbcdn.net/v/t1.0-9/67181106_913440482342705_8168422051984441344_n.jpg?_nc_cat=102&_nc_oc=AQkpI19WlOumQP-81m8x7lPNz3s3E82ZiwMgZ6X3NLp0hBQR1ICzswmo3cDMW0y__-8&_nc_ht=scontent.fkhh1-1.fna&oh=dc50cc3fa652d65e2ef644a83c02cf90&oe=5DED2CF5"
img_ok = "https://scontent.fkhh1-1.fna.fbcdn.net/v/t1.0-9/67301384_913440575676029_1834425191191543808_n.jpg?_nc_cat=105&_nc_oc=AQkwa9UTmxgHH1Wxj5Sgdk649PIOhYQ2M3rc1m-QfF-dPJh2xLKS0oLJQlzT0y4pE98&_nc_ht=scontent.fkhh1-1.fna&oh=71ea7aee51a0eb4da8a00cf2d9e949b8&oe=5DB5B61F"
img_smile = "https://scontent.fkhh1-2.fna.fbcdn.net/v/t1.0-9/67412582_913440569009363_1431190674778095616_n.jpg?_nc_cat=111&_nc_oc=AQk8HNJTMJzTc6Pxleayqz3nVp1Aqhhz4Okio2XjOu1kBIIu-BkjpUxh5Q94Cm0rMYU&_nc_ht=scontent.fkhh1-2.fna&oh=a1cabd565ac5e946ee33e755aae87cc7&oe=5DEEA611"
img_doorplate = "https://scontent.ftpe12-2.fna.fbcdn.net/v/t1.0-9/61078857_875267386160015_4437566467994550272_n.jpg?_nc_cat=110&_nc_eui2=AeGcYmXCQge4PFlRf7H0MOUxf1pMxIHCJXPuLC6zsdYHArI3OvX1Cj7RbqRXyf1OzM0My-iebhNKWSwnZKsC1m_6GhyOVGZYq5XbsAUi9ck77A&_nc_ht=scontent.ftpe12-2.fna&oh=223c83920133792c4e4efff794795d81&oe=5D9E7DC1"

title_update1 = "【舉報案件進度回報】\n您於2019年5月25日14:30舉報位於台北市復興南路二段18號的廢棄腳踏車，清潔隊員已經於2019年5月27日去現場勘查，並且確認符合處理規定，已張貼告示在腳踏車上，大約七天後清潔隊員會再次前往勘查，若腳踏車和告示都留在原地未被更動，清潔隊員就會回收。\n歡迎您去現場看看您的成果!\n再次感謝您對社區環境的貢獻，也希望您再接再厲喔!"
title_update2 = "【舉報案件進度回報】\n您於2019年5月25日14:30舉報位於台北市復興南路二段18號的廢棄腳踏車，，清潔隊員於2019年6月7日再次現場勘查，確認告示逾七日無人表示異議，清潔隊員已經依照規定回收囉!\n歡迎您去現場看看您的成果!\n再次感謝您對社區環境的貢獻，也希望您再接再厲喔!"

title0 = "Welcome to the <BikeR>, Chatbot Cyclon is serving you now!"

buttons0 = [
    ActionButton(ButtonType.POSTBACK, "Start reporting", "Start reporting"),
    ActionButton(ButtonType.POSTBACK, "How to use", "How to use"),
    ActionButton(ButtonType.POSTBACK, "Scores & Settings", "Scores & Settings"),
]

buttons1 = [
    ActionButton(ButtonType.POSTBACK, "Back to lobby", "Back to lobby"),
]

title2 = "<BikeR> is a non-profit initiative started in 2016 by a group of elementary school students.  Our goal is to help everyone report abandoned bicycles on the streets, so the City Rubbish Collection Agency can pick them up for recycling."

buttons2 = [
    ActionButton(ButtonType.POSTBACK, "What is abandoned bicycle", "怎麼判斷是廢棄的腳踏車"),
    ActionButton(ButtonType.POSTBACK, "Recycling procedure", "廢棄腳踏車處理流程"),
    ActionButton(ButtonType.POSTBACK, "Suggestions & Feedbacks", "建議與回饋")
]

buttons3 = [
    ActionButton(ButtonType.POSTBACK, "Change name", "變更稱呼"),
    ActionButton(ButtonType.POSTBACK, "Change phone number", "變更電話"),
]

buttons3a = [
    ActionButton(ButtonType.POSTBACK, "Upload photos", "上傳照片"),
    ActionButton(ButtonType.POSTBACK, "Change your name", "變更稱呼"),
    ActionButton(ButtonType.POSTBACK, "Change your phone number", "變更電話"),
]

buttons3b = [
    ActionButton(ButtonType.POSTBACK, "Upload photos", "上傳照片"),
]

buttons4 = [
    ActionButton(ButtonType.POSTBACK,"Confirm reporting", "確認送出舉報內容"),
    ActionButton(ButtonType.POSTBACK,"Give up reporting", "Give up reporting")
]

buttons5 = [
    ActionButton(ButtonType.POSTBACK,"Submit verification", "確認舉報資料無誤，請人工處理"),
    ActionButton(ButtonType.POSTBACK,"Give up reporting", "Give up reporting")
]

buttons6 = [
    ActionButton(ButtonType.POSTBACK,"Details", "細節"),
    ActionButton(ButtonType.POSTBACK,"Cancel", "撤銷")
]

levelname = ["K1", "K2", "K3", "K4", "K5", "K6", "K7", "K8", "K9", "K10", "K11", "K12", "K13", "K14", "K15", "K16", "K17", "K18", "K19", "K20", "K21"]

def hasNumbers(inputString):
    return any(char.isdigit() for char in inputString)

def handle_message(messaging_event):  # the entrance of the chatbot. this function will be excuted for every message the user send to chatbot.
    resp = tableusermessage.get_item(Key={'sender_idz':messaging_event['sender']['id'], 'timez':messaging_event['timestamp']})
    if len(resp)>1:
        print("GetItem succeeded, already exist, do nothing", len(resp))
    else:
        tableusermessage.put_item(Item={'sender_idz':messaging_event['sender']['id'],'timez':messaging_event['timestamp']})
        talkuser(messaging_event) # call the function name 'talkuser' in below

def talkuser(messaging_event):
    recipient_id = messaging_event["sender"]["id"] #get user's unique ID to response to 
    resp = tablevoiceone.get_item(Key={'sender_idz':recipient_id}) #get the item values from dynamodb with the user's ID
    if (len(resp)<2):  #if there is no any item matchs the user's ID, means this is a new user for the fanpage messenger 
        tablevoiceone.put_item(Item={'sender_idz':recipient_id,'namez':"unknown",'pnum':"unknown",'switch':0,'picture':0,'correct':-1,'newclient':1,'credit':"0.0", 'totalz':0,'consecution':0,'localz':0,'score':0,'details':"-"})  #create a new item with default value
    resp = tablevoiceone.get_item(Key={'sender_idz':recipient_id}) #get user info by id from the cloud database
    item = resp['Item'] #arange the list 'item' with the data in database for this user
    switch = item["switch"] #get 'switch' value. It descript the status of the user, for example switch=7 means the user is giving feedback to us
    if "postback" in messaging_event:   #In the case that the user send a postback, a special type of message. Postback is button clicked.
        payloadtx = messaging_event["postback"]["title"] #recognize response and arrange it to the valiable 'payloadtx'
#        if payloadtx != "Get Started":
#            payloadtx = messaging_event["postback"]["payload"] #recognize response and arrange it to the valiable 'payloadtx'
        if payloadtx == "Get Started" or payloadtx == "Back to lobby" or payloadtx =="Give up reporting": # in case that the user go to the entrance of the conversation
            client.send_image(recipient_id, img_smile) #send symbolic image of the initiative
            client.send_buttons(recipient_id, title0, buttons0) #send text and buttons to welcome new user
            tablevoiceone.update_item(Key={'sender_idz': recipient_id},UpdateExpression="set switch = :a",ExpressionAttributeValues={':a': 0}) #update user status to entrance         
        elif payloadtx == "How to use": #if the user wants to know more about the initiative
#            client.send_image(recipient_id,"https://scontent.ftpe11-1.fna.fbcdn.net/v/t1.0-9/17098550_411276342559124_9132392283706263628_n.jpg?_nc_cat=102&_nc_ht=scontent.ftpe11-1.fna&oh=11a9282d5435406de6c16aa95aa4bb6c&oe=5D35274D") #send symbolic image of the initiative
            client.send_image(recipient_id,"https://scontent.ftpe12-1.fna.fbcdn.net/v/t1.0-9/61247413_874283832925037_2067012891634040832_o.jpg?_nc_cat=103&_nc_eui2=AeEJ5rT9dEt2-tY27RRJKwOtrfVDPM0F3a5ATB6dc7R3Hdu-qiAlDxx9vxcC153BUS5O8FzCrbdgqr_ZR1HS8Yp9Jeb55QqzPfO3hRpghZRM6A&_nc_ht=scontent.ftpe12-1.fna&oh=f5baf242e3c57b15afb458713347fbd4&oe=5D5142AD") #send symbolic image of the initiative
            client.send_buttons(recipient_id, title2, buttons2) #send event info and more buttons to link to other info
            tablevoiceone.update_item(Key={'sender_idz': recipient_id},UpdateExpression="set switch = :a",ExpressionAttributeValues={':a': 0}) #update user status to entrance        
        elif payloadtx == "What is abandoned bicycle": #if the user wants to know more about the criteria of broken bike to be recycled.
            client.send_image(recipient_id,"https://scontent.ftpe11-1.fna.fbcdn.net/v/t1.0-9/16806647_402936603393098_4996495945397619203_n.jpg?_nc_cat=102&_nc_ht=scontent.ftpe11-1.fna&oh=54f2057f010f3672d14683897c455681&oe=5D3486C0") #send an image of broken bike
            client.send_buttons(recipient_id, "Criteria for abandoned bicycle : Heavy rusting, missing major parts, etc. such that it can not be functional.", buttons2) #send info and buttons
            tablevoiceone.update_item(Key={'sender_idz': recipient_id},UpdateExpression="set switch = :a",ExpressionAttributeValues={':a': 0}) #update user status to entrance        
        elif payloadtx == "Recycling procedure": # wants to know the process of recycling broken bike.
            client.send_image(recipient_id,"http://recycle.epb.taichung.gov.tw/sweep/images/img_sale-09.gif") #send an image 
            client.send_buttons(recipient_id, "Information on the recycling procedure : Once the City Rubbish Collection Agency received your report, will be at the abandoned bicycle site within 3 working days to check.  If indeed the bicycle you reported is an abandoned bicycle, they will post a notice on the bicycle.  After 7 days, the Agency will come back to make sure no one has claimed the bicycle.  Thereafter they will pick up the bicycle in a collection site, and post a notice on the internet for one month.  If still no one makes a claim for the bicycle, the Agency will disassemble the bicycle for recycling.", buttons2) #send info and buttons
            tablevoiceone.update_item(Key={'sender_idz': recipient_id},UpdateExpression="set switch = :a",ExpressionAttributeValues={':a': 0}) #update status to entrance        
        elif payloadtx == "Suggestions & Feedbacks": # to send feedback to us
            client.send_image(recipient_id, img_great)
            client.send_buttons(recipient_id, "We value your suggestions, please give your suggestions.\n\nIf no suggestions, please press “Back to Lobby”.", buttons1) #send message and button
            tablevoiceone.update_item(Key={'sender_idz': recipient_id},UpdateExpression="set switch = :a",ExpressionAttributeValues={':a': 7}) #set status to typing        
        elif payloadtx == "Change name": # to change user's name
            client.send_buttons(recipient_id, "Please provide you name.\n\nOtherwise, please press “Back to Lobby”.", buttons1) #send message and button
            tablevoiceone.update_item(Key={'sender_idz': recipient_id},UpdateExpression="set switch = :a",ExpressionAttributeValues={':a': 1}) #set status to typing        
        elif payloadtx == "Change phone number": # to change user's phone number
            client.send_buttons(recipient_id, "Please provide your phone number.\nOtherwise, please press “Back to Lobby”.", buttons1) #send message to typing
            tablevoiceone.update_item(Key={'sender_idz': recipient_id},UpdateExpression="set switch = :a",ExpressionAttributeValues={':a': 2}) #set status to typing        
        elif payloadtx == "Scores & Settings": # to show user's achievements
            client.send_image(recipient_id, img_heart)
            ilv = round(float(item['credit']))+min(int(item['totalz']),50)//5 
            tablevoiceone.update_item(Key={'sender_idz': recipient_id},UpdateExpression="set switch = :a",ExpressionAttributeValues={':a': 0}) #set status to entrance and update the total report number        
            resp1 = tablereport.query(KeyConditionExpression=Key('sender_idz').eq(recipient_id)) #get the reported item values from dynamodb 'bikereport' with the user's ID
            for i in resp1['Items']:
                client.send_buttons(recipient_id,"Date:"+i['timestampz'][0:10]+"\nAddress:"+i['address']+"(Remark:"+str(i['details'])+")\nProgress:"+i['status'],[ActionButton(ButtonType.POSTBACK,"Details", i['timestampz']),ActionButton(ButtonType.POSTBACK,"Cancel", i['timestampz'])])
            client.send_buttons(recipient_id,"Name:"+item['namez']+"\nPhone number:"+item['pnum']+"\nScore："+str(round(float(item['credit'])) )+"\nLevel["+ levelname[ilv]+"]\n"+str(item['totalz'])+" report in total.\n0 bike recycled.\n"+str(item['totalz'])+"report outstanding. \nBelow please find your reports!", buttons1) #give status report
        elif payloadtx == "Details":
            resp1 = tablereport.query(KeyConditionExpression=Key('sender_idz').eq(recipient_id) & Key('timestampz').eq(messaging_event["postback"]["payload"])) #get the reported item values from dynamodb 'bikereport' with the item ID matching with timestampz field
            for i in resp1['Items']:
                client.send_image(recipient_id,i['bikephoto']) #send an image 
                client.send_buttons(recipient_id,"Name:"+i['namez']+"\nPhone:"+i['pnum']+"\nDate of reporting:"+i['timestampz'][0:10]+"\nAddress:"+i['address']+"(Remark:"+str(i['details'])+")\nProgress:"+i['status']+"\nUpdate:"+i['updatedate'][0:10],[ActionButton(ButtonType.POSTBACK,"Cancel", i['timestampz'])])
        elif payloadtx == "Cancel":
            resp1 = tablereport.query(KeyConditionExpression=Key('sender_idz').eq(recipient_id) & Key('timestampz').eq(messaging_event["postback"]["payload"])) #get the reported item values from dynamodb 'bikereport' with the item ID matching with timestampz field
            for i in resp1['Items']:
                client.send_image(recipient_id, img_cry)
                client.send_buttons(recipient_id,"Confirm to cancel?",[ActionButton(ButtonType.POSTBACK,"Confirm cancel", i['timestampz']),ActionButton(ButtonType.POSTBACK, "Back to lobby", "Back to lobby")])
        elif payloadtx == "Confirm cancel":
            resp1 = tablereport.query(KeyConditionExpression=Key('sender_idz').eq(recipient_id) & Key('timestampz').eq(messaging_event["postback"]["payload"])) #get the reported item values from dynamodb 'bikereport' with the item ID matching with timestampz field
            for i in resp1['Items']:
                tablereportbackup.put_item(Item=i)  #copy a record from bikereport table to bikereportbackup table for backup purpose before deleting it 
            tablereport.delete_item(Key={'sender_idz': recipient_id, 'timestampz': messaging_event["postback"]["payload"]})  # delete it from bikereport table
            tablevoiceone.update_item(Key={'sender_idz': recipient_id},UpdateExpression="set switch = :a, totalz = :b",ExpressionAttributeValues={':a': 0, ':b': int(item['totalz'])-1}) #set status to entrance and update the total report number        
            client.send_buttons(recipient_id,"Ok. It has been canceled!", buttons1) 
        elif payloadtx == "Start reporting": # to start to report a broken bike
            if item['namez']=='unknown' or item['pnum']=='unknown': #if either usermane or phone number is not provided 
                client.send_image(recipient_id, img_stop)
                client.send_buttons(recipient_id, "Per government regulations, please provide your name and phone number.  Thank you!\n\nYour name:"+item['namez']+"\nPhone number:"+item['pnum'], buttons3) #ask for name and number
            else: #existing number and name
                client.send_buttons(recipient_id, "Please take a photo of the abandoned bicycle and upload it to me, thanks.\n\nName:"+item['namez']+"\nPhone:"+item['pnum'], buttons3a) # ask user to send image of broken bike 
                tablevoiceone.update_item(Key={'sender_idz': recipient_id},UpdateExpression="set switch = :a",ExpressionAttributeValues={':a': 3}) #send photo        
        elif payloadtx == "Upload photos": # to upload an image of broken bike
            client.send_image(recipient_id, img_letsgo)
            client.send_text(recipient_id,"Upload a photo, please.") #ask for photo
            tablevoiceone.update_item(Key={'sender_idz': recipient_id},UpdateExpression="set switch = :a",ExpressionAttributeValues={':a': 4}) #send photo        
        elif switch==6 and (payloadtx == "Confirm reporting" or payloadtx == "Submit verification"): # to confirm reporting
            final = float(int(item['score']) + float(item['credit'])*int(item["totalz"]))/(int(item["totalz"])+1) #recalculate credit score including the score of new report
            if payloadtx == "Confirm reporting": # if the report was recognized by AI as a high score one and the user confirmed to sumbit.
                email_reply.send_email("dfctw2017@gmail.com","<BikeR> Volunteers report cases", "Dear sir/madam,\n\nThe reported the case in below has been screened by our AI already. It is a valid report. Please arrange a cleaning team to recheck and recycle it, thank you. \n\nContact Person: "+item['namez']+"\nPhone Number "+item['pnum']+"\nAddress: "+item['address']+"(Remark:"+str(item['details'])+")\nPhoto: "+item['urlz']+"\n\nThe score for this case is "+str(item['score'])+" (Out of 10 points).\n\nThanks for your contributions to Taiwan's environment.\n\nCheers,\nBikeR!") #send email
                client.send_image(recipient_id, img_ok)
                client.send_text(recipient_id,"OK, I will send this reporting to the City Rubbish Collection Agency, and they will come to inspect the abandoned bicycle within one week.  A notice will be posted on the bicycle if it meets the abandoned bicycle criteria!  Let me bring you Back to the Lobby.") #respond confirmation
            else:  # payloadtx == "確認舉報資料無誤，請人工處理"  # if this is a report with low score and the user is still keen to sumbit it.
                email_reply.send_email("dfctw2017@gmail.com","Request for manual checking:<BikeR> Volunteers report cases", "Dear sir/madam,\n\nThe reported the case in below has been screened by our AI already. It needs manual checking. Please arrange a cleaning team to recheck and recycle it if you think it is valid, thank you. \n\nContact Person: "+item['namez']+"\nPhone Number "+item['pnum']+"\nAddress: "+item['address']+"(Remark:"+str(item['details'])+")\nPhoto: "+item['urlz']+"\n\nThe score for this case is "+str(item['score'])+" (Out of 10 points).\n\nThanks for your contributions to Taiwan's environment.\n\nCheers,\nBikeR!") #send email
                client.send_image(recipient_id, img_ok)
                client.send_text(recipient_id,"OK, I will send this reporting to the City Rubbish Collection Agency, and they will come to inspect the abandoned bicycle within one week.  A notice will be posted on the bicycle if it meets the abandoned bicycle criteria!  Let me bring you Back to the Lobby."
                )                
            tablevoiceone.update_item(Key={'sender_idz': recipient_id},UpdateExpression="set switch = :a, score = :b, credit = :c, totalz = :d, picture = :e, correct = :f, newclient = :g, consecution = :h, localz = :i",ExpressionAttributeValues={':a': 0, ':b':0, ':c':str(final), ':d':int(item["totalz"])+1, ':e':0, ':f':-1, ':g':0, ':h':0, ':i':0 }) #reset status        
            tablereport.put_item(Item={'rid':int(time.mktime(datetime.datetime.now().timetuple())),'timestampz':str(datetime.datetime.now()), 'sender_idz':recipient_id,'namez':item['namez'],'pnum':item['pnum'],'bikephoto':item['urlz'], 'cityz':item['email'], 'address':item['address'], 'score': item['score'], 'latz': item['latz'], 'longz': item['longz'], 'status':"Reported", 'handler':"unknown", 'updatedate':str(datetime.datetime.now()), 'details':item['details']})  #create a new item with default value
            client.send_buttons(recipient_id, title0, buttons0) #send entrance buttons
        elif switch==5 and payloadtx == "Add Remark": # to add more details for the address
            client.send_buttons(recipient_id, "Address:"+messaging_event["postback"]["payload"]+"\n\nPlease input your remark.\nIf the remark is not required, press the [Confirm Location] button.",[ActionButton(ButtonType.POSTBACK,"Confirm Location",messaging_event["postback"]["payload"])]) #send message and button
            tablevoiceone.update_item(Key={'sender_idz': recipient_id},UpdateExpression="set switch = :a",ExpressionAttributeValues={':a': 8}) #set status to typing        
        elif switch==8 and payloadtx == "Edit Remark": # to add more details for the address
            client.send_buttons(recipient_id, "Address:"+messaging_event["postback"]["payload"]+"(Remark:"+item['details']+")\n\Please input your remark.\nIf you don't want to modify, press the [Confirm Location] button.",[ActionButton(ButtonType.POSTBACK,"Confirm Location",messaging_event["postback"]["payload"])]) #send message and button
        elif (switch==5 or switch==8) and payloadtx == "Confirm Address": # to confirm the address
            georesult = requests.get(url = "http://api.opencube.tw/location/address", params = {'keyword':messaging_event["postback"]["payload"], 'key':"AIzaSyBI4ALNfd_6bVXSPG2h1Z-WxRbu0kuOWZs"}) 
            geojson = georesult.json()
            if geojson['data']['country']=="TW": # if it is a location within Taiwan
                intaiwan = 1
            else:
                intaiwan = 0    
            name = item['namez']
            phone = item['pnum']
            addr = geojson['data']['full_address']
            client.send_text(recipient_id,"Cyclon is processing the case via AI system, please wait a moment…")
            score = predict.keras_predict(int(item['picture']), int(item['correct']), int(item['newclient']), float(item["credit"]), int(item['totalz']), int(item["consecution"]), int(intaiwan))
            if (len(addr)<5 or len(addr)>30):  # to discount the score if the address is too short or too long, this is a turn around be we re-train the AI
                score = round(score * 0.7)
            if ("路" not in addr) and ("街" not in addr): # as above, discount if the address doesn't contain any important keyword
                score = round(score * 0.8) 
            if ("號" not in addr): # as above, discount if the address doesn't contain any important keyword
                score = round(score * 0.6) 
            tablevoiceone.update_item(Key={'sender_idz': recipient_id},UpdateExpression="set switch = :a, score=:b, address=:c, email=:d, localz=:e, latz=:f, longz=:g",ExpressionAttributeValues={':a': 6, ':b':int(score), ':c':addr, ':d':geojson['data']['city'], ':e':int(intaiwan), ':f':str(geojson['data']['lat']), ':g':str(geojson['data']['lng'])})         
            if score >= 7:
                client.send_image(recipient_id, img_great)
                client.send_buttons(recipient_id, "Super! You have received "+str(score)+" points for this reporting！\nBelow is the details\nName："+str(name)+"\nPhone："+str(phone)+"\nLocation:"+addr+"(Remark:"+str(item['details'])+")", buttons4) #send if enough points
            else:
                client.send_image(recipient_id, img_cry)
                client.send_buttons(recipient_id, "Sorry! You got "+str(score)+" point only for this reporting! \nIt needs to be manually checked before submitting to government. Still proceed?", buttons5) #ask to send if not enough points
        else:
            client.send_image(recipient_id, img_sorry)
            client.send_buttons(recipient_id, "I'm not able to recognize the instruction you sent!\n\n"+payloadtx+"\n\n"+title0, buttons0) #send response to those postback button that is not pre-designed.
            tablevoiceone.update_item(Key={'sender_idz': recipient_id},UpdateExpression="set switch = :a",ExpressionAttributeValues={':a': 0}) #set status to entrance        
    elif "message" in messaging_event and "quick_reply" in messaging_event["message"]:    #In the case that the user has clikc on a quick reply button
        text=messaging_event["message"]["quick_reply"]["payload"]
        if switch == 5 and text=="textaddress":
            client.send_text(recipient_id,"Ok, please input the address in text.")
        if switch == 5 and text=="doorplate":
            client.send_image(recipient_id, img_doorplate)
            client.send_text(recipient_id,"Please upload the photo of the nestest door plate for AI recognition.")
        else:
            client.send_image(recipient_id, img_sorry)
            client.send_buttons(recipient_id, "I'm not able to recognize the payload you sent!\n\n"+title0, buttons0) #send response to those postback button that is not pre-designed.
            tablevoiceone.update_item(Key={'sender_idz': recipient_id},UpdateExpression="set switch = :a",ExpressionAttributeValues={':a': 0}) #set status to entrance        
    elif "message" in messaging_event and "text" in messaging_event["message"]:   #In the case that the user send a text message
        text = messaging_event["message"]["text"] #put sent text into the valiable 'text'
        if switch == 7: #if user is sending feedbacks to us
            email_reply.send_email("dfctw2017@gmail.com","<BikeR> user feedback", "this is one of <BikeR>'s user's feedback report.please foward this to the volenteers to be analyzed and discussed.\n\nName:"+str(item['namez'])+"\nPhone:"+str(item['pnum'])+"\nFeedback:\n-----------\n"+text+"\n-----------\n\nP.S. Do not respond.") #send an email with proper content to the operation team
            client.send_image(recipient_id, img_ok)
            client.send_text(recipient_id,"Good! The message has been sent.") #send text response to user
            tablevoiceone.update_item(Key={'sender_idz': recipient_id},UpdateExpression="set switch = :a",ExpressionAttributeValues={':a': 0}) #status:　entrance        
            client.send_buttons(recipient_id, title0, buttons0) #send entrance buttons
        elif switch == 1: #change name
            tablevoiceone.update_item(Key={'sender_idz': recipient_id},UpdateExpression="set switch = :a, namez=:b",ExpressionAttributeValues={':a': 0, ':b':text})         
            item['namez'] = text
            if item['namez']=='unknown' or item['pnum']=='unknown':
                client.send_buttons(recipient_id, "According to requlation, you have to provide your name and phone number to the cleaning team in order to report bikes.\n\nName:"+item['namez']+"\nPhone:"+item['pnum'], buttons3)
            else:
                client.send_buttons(recipient_id, "Please send me a photo of the bike/bikes you want to report.\n\nName:"+item['namez']+"\nPhone:"+item['pnum'], buttons3a)
            tablevoiceone.update_item(Key={'sender_idz': recipient_id},UpdateExpression="set switch = :a",ExpressionAttributeValues={':a': 3})         
        elif switch == 2: #change phone
            if (len(text) != 10) or (text[0:2] != "09"):
                client.send_buttons(recipient_id, "Please provide a CORRECT phone number.\nProviding correct phone number will raise up the score!\nIf you don't want to change, press <Back to Lobby>.", buttons1) #send message to typing
            else:
                tablevoiceone.update_item(Key={'sender_idz': recipient_id},UpdateExpression="set switch = :a, pnum = :b",ExpressionAttributeValues={':a': 0, ':b':text})         
                item['pnum'] = text
                if item['namez']=='unknown' or item['pnum']=='unknown':
                    client.send_buttons(recipient_id, "According to requlation, you have to provide your name and phone number.\n\nName:"+item['namez']+"\nPhone:"+item['pnum'], buttons3)
                else:
                    client.send_buttons(recipient_id, "Please send me a photo of the bike/bikes you want to report.\n\nName:"+item['namez']+"\nPhone:"+item['pnum'], buttons3a)
                    tablevoiceone.update_item(Key={'sender_idz': recipient_id},UpdateExpression="set switch = :a",ExpressionAttributeValues={':a': 3})         
        elif switch == 5: #send address in text message
            client.send_text(recipient_id,"Thank you! Cyclon AI is processing...")
            georesult = requests.get(url = "http://api.opencube.tw/location/address", params = {'keyword':text, 'key':"AIzaSyBI4ALNfd_6bVXSPG2h1Z-WxRbu0kuOWZs"}) 
            geojson = georesult.json()
            if geojson['status'] == 200:  # if the api return OK status
                client.send_text(recipient_id, geojson['data']['full_address'])
                client.send_buttons(recipient_id,"If the address is correct, please press <Confirm Address>. Otherwise please provide me again.\nIf the location is complicated, please provide remark.",[ActionButton(ButtonType.POSTBACK,"Confirm Address", geojson['data']['full_address']),ActionButton(ButtonType.POSTBACK,"Add Remark", geojson['data']['full_address'])])
                tablevoiceone.update_item(Key={'sender_idz': recipient_id},UpdateExpression="set address = :a, email = :b, latz = :c, longz = :d, details = :e",ExpressionAttributeValues={':a': geojson['data']['full_address'], ':b':geojson['data']['city'], ':c': str(latz), ':d':str(longz), ':e':"-"})         
            else:
                client.send_image(recipient_id, img_sorry)
                client.send_quick_replies(recipient_id,"Sorry, I'm not able to understand the address!\n\nPlease provide via map location or text!",[QuickReply("Door Plate", "doorplate"),QuickReply("Map", "位置",None,ContentType.LOCATION),QuickReply("Text", "textaddress")]) #ask for location of the broken bike
        elif switch == 8: #send more details about address in text message
            tablevoiceone.update_item(Key={'sender_idz': recipient_id},UpdateExpression="set switch = :a, details = :b",ExpressionAttributeValues={':a': 8, ':b':str(text)})         
            client.send_image(recipient_id, img_ok)
            client.send_buttons(recipient_id, "Remark!\naddress:"+item['address']+"(remark:"+str(text)+")",[ActionButton(ButtonType.POSTBACK,"Confirm Address",item['address']),ActionButton(ButtonType.POSTBACK,"Edit Remark",item['address'])]) #send message and button
        else:            
            client.send_buttons(recipient_id, "??????\n\n"+title0, buttons0)
            tablevoiceone.update_item(Key={'sender_idz': recipient_id},UpdateExpression="set switch = :a",ExpressionAttributeValues={':a': 0}) #status: entrance        
    else:
        for attachment in messaging_event["message"]["attachments"]: #if message has attatchments
            if (attachment["type"] == "image") and (switch==4 or switch==0 or switch==3): #if attachment is image
                if item['namez']=='unknown' or item['pnum']=='unknown': #if either usermane or phone number is not provided 
                    client.send_image(recipient_id, img_stop)
                    client.send_buttons(recipient_id, "You have not provide contact information yet. Please provide your name and phone number for the first reporting.\n\nName:"+item['namez']+"\nPhone:"+item['pnum'], buttons3) #ask for name and number
                else:
                    tablevoiceone.update_item(Key={'sender_idz': recipient_id},UpdateExpression="set picture = :a",ExpressionAttributeValues={':a': 1}) #status: photo
                    client.send_text(recipient_id,"Photo received and processing…")
                    url = attachment["payload"]["url"] #initualize url
                    ans = vision.detect_labels_uri(url,"bicycle") #send to google vision api for diagnosis
                    tablevoiceone.update_item(Key={'sender_idz': recipient_id},UpdateExpression="set urlz = :a",ExpressionAttributeValues={':a': url})
                    if float(ans) >= 7.0:
                        tablevoiceone.update_item(Key={'sender_idz': recipient_id},UpdateExpression="set correct = :a, switch=:b",ExpressionAttributeValues={':a': 1, ':b':5}) #set status to sending photo
                        client.send_image(recipient_id, img_great)
                        client.send_text(recipient_id,"Great! I saw the bike. It's likelihood score is "+str(ans)+" points, please tell me its location!") #send message to tell that AI has recognized a bike in the photo
                    else:
                        tablevoiceone.update_item(Key={'sender_idz': recipient_id},UpdateExpression="set correct = :a, switch=:b",ExpressionAttributeValues={':a': 0, ':b':5}) #set status to sending photo
                        client.send_image(recipient_id, img_sorry)
                        client.send_buttons(recipient_id, "Oh no! It is not likely an abandoned bike, its likelihood score is only "+str(ans)+" point. Maybe you can take another photo of it!", buttons3b) # ask user to resend image of broken bike 
                        client.send_text(recipient_id,"If you are sure that it is an abandoned bike, please provide its location!")#send message to tell that AI can not find any bike in the photo.
                    client.send_quick_replies(recipient_id,"Please provide me its location.\n\nRemind you that the address must be accurate, because the cleaning team will go to the scene to investigate based on the address you provided. If the address is wrong, the hard-working cleaning team will run for nothing!!\n\nYou can also provide via the map or directly in text for me!",[QuickReply("門牌辨識", "doorplate"),QuickReply("位置", "位置",None,ContentType.LOCATION),QuickReply("文字輸入", "textaddress")]) #ask for location of the broken bike
            elif (attachment["type"] == "image") and (switch==5): #if attachment is a door plate
                url = attachment["payload"]["url"] #initualize url
                addr = visionAddress.doorplate_recognition(url) # detect house number plate
                client.send_text(recipient_id,"Photo of door plate received and processing…")
                if addr:
                    client.send_text(recipient_id,"Some pieces of text had been recognized:\n"+addr)
                    client.send_text(recipient_id,"Trying to put them together...")
                    georesult = requests.get(url = "http://api.opencube.tw/location/address", params = {'keyword':addr, 'key':"AIzaSyBI4ALNfd_6bVXSPG2h1Z-WxRbu0kuOWZs"}) 
                    geojson = georesult.json()
                    if geojson['status'] == 200:  # if the api return OK status
                        client.send_text(recipient_id, geojson['data']['full_address'])
                        client.send_buttons(recipient_id,"If the address is correct, press the button to send it to me. Or you can take another shot and give me a try again, or you can type in the text directly! \nIf you are worried that the cleaning team cannot find it, you can also add a remark.",[ActionButton(ButtonType.POSTBACK,"Confirm Address", geojson['data']['full_address']),ActionButton(ButtonType.POSTBACK,"Add Remark", geojson['data']['full_address'])])
                        tablevoiceone.update_item(Key={'sender_idz': recipient_id},UpdateExpression="set address = :a, email = :b, latz = :c, longz = :d, details = :e",ExpressionAttributeValues={':a': geojson['data']['full_address'], ':b':geojson['data']['city'], ':c': str(geojson['data']['lat']), ':d':str(geojson['data']['lng']), ':e':"-"})         
                    else:
                        client.send_image(recipient_id, img_sorry)
                        client.send_quick_replies(recipient_id,"Sorry, Cyclon is not able to recognize the door plate!\n\nYou can also provide via the map or directly in text for me!",[QuickReply("Door Plate", "doorplate"),QuickReply("Map Location", "位置",None,ContentType.LOCATION),QuickReply("Text Input", "textaddress")]) #ask for location of the broken bike
                else:
                    client.send_image(recipient_id, img_sorry)
                    client.send_quick_replies(recipient_id,"Oh no, it looks not like a door plate!\n\nYou can also provide via the map or directly in text for me!",[QuickReply("Door Plate", "doorplate"),QuickReply("Map Location", "位置",None,ContentType.LOCATION),QuickReply("Text Input", "textaddress")]) #ask for location of the broken bike
            elif (attachment["type"] == "location") and (switch==5): #if attachment is location
                latz = attachment["payload"]["coordinates"]["lat"]
                longz = attachment["payload"]["coordinates"]["long"]
                georesult = requests.get(url = "http://api.opencube.tw/location", params = {'lat':str(latz), 'lng':str(longz), 'key':"AIzaSyBI4ALNfd_6bVXSPG2h1Z-WxRbu0kuOWZs"}) 
                geojson = georesult.json()
                client.send_text(recipient_id,geojson['data']['full_address'])
                tablevoiceone.update_item(Key={'sender_idz': recipient_id},UpdateExpression="set address = :a, email = :b, latz = :c, longz = :d, details = :e",ExpressionAttributeValues={':a': geojson['data']['full_address'], ':b':geojson['data']['city'], ':c': str(latz), ':d':str(longz), ':e':"-"})         
                client.send_buttons(recipient_id,"If the address is correct, press the button to send it to me.\nRemind you again that the address must be accurate, otherwise the hard-working cleaning team will run for nothing!!!!\nIf you are worried that the cleaning team cannot find it, you can also add a remark.",[ActionButton(ButtonType.POSTBACK,"Confirm Address",geojson['data']['full_address']),ActionButton(ButtonType.POSTBACK,"Add Remark", geojson['data']['full_address'])])
                client.send_quick_replies(recipient_id,"Or you can also resend the address.",[QuickReply("Door Plate", "doorplate"),QuickReply("Map Location", "位置",None,ContentType.LOCATION),QuickReply("Text Input", "textaddress")])
            else: #if don't understand response. It means that the user sent a unexpected response to Chatbot.
                tablevoiceone.update_item(Key={'sender_idz': recipient_id},UpdateExpression="set switch = :a",ExpressionAttributeValues={':a': 0}) 
                client.send_image(recipient_id, img_stop)
                client.send_buttons(recipient_id, "What's that? HA!\n\n"+title0, buttons0) #send message
