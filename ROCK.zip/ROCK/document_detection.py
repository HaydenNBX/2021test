#!/usr/bin/python
# -*- coding: utf-8 -*-

import io
# Imports the Google Cloud client library
from google.cloud import vision

# Instantiates a client
client = vision.ImageAnnotatorClient()

def detect_document_uri(uri):
    import requests
    with open('plate1.jpg', 'wb') as handle:
            response = requests.get(uri, stream=True)

            if not response.ok:
                print (response)

            for block in response.iter_content(1024):
                if not block:
                    break

                handle.write(block)

    from google.cloud import vision
    from google.cloud.vision import types

    vision_client = vision.ImageAnnotatorClient()
    file_name = 'plate1.jpg'

    with io.open(file_name,'rb') as image_file:
        content = image_file.read()
    image = types.Image(content=content)
    response = vision_client.document_text_detection(image=image)
    texts = response.text_annotations
    return_string = ''
    if len(texts):
        del texts[0]
        for text in texts:
            return_string = return_string + str(text.description) + ','          
        return return_string
    else:
        return None
lst = detect_document_uri('https://www-ws.gov.taipei/001/Upload/public/MMO/DAHR1/%E7%8F%BE%E8%A1%8C%E9%96%80%E7%89%8C.jpg')
print(lst)