#!/usr/bin/python
# -*- coding: utf-8 -*-

import json

from flask import Flask, request
from pymessager.message import Messager

# vision lib
import vision.vision as vision

# message handler
import bothandlerfelix as bot_handlerfelix
import bothandlerRock as bot_handlerRock
import bothandler as bot_handler

WEBHOOK = '/webhook'
with open('config.json', 'r') as f:
    config = json.load(f)
    print(config)

app = Flask(__name__)
client = Messager(config['FACEBOOK']['ACCESS_TOKEN'])


@app.route("/")
def hello():
    return "Hello World!"

@app.route(WEBHOOK, methods=["GET"])
def fb_webhook():
    verify_token = request.args.get('hub.verify_token')
    if config['FACEBOOK']['VERIFICATION_TOKEN'] == verify_token:
        return request.args.get('hub.challenge')
    else:
        return '', 403


@app.route(WEBHOOK, methods=['POST'])
def fb_receive_message():
    data = json.loads(request.data.decode('utf8'))
    print("received========================")
    print(data)    
    message_entries = data['entry']
    for entry in message_entries:
        for message in entry['messaging']:
            if (message["sender"]["id"] == "2497197137021734"):  # rock trying, find your id in AWS dynamodb table item
                try:
                    bot_handler.handle_message(message)
                except:
                    print("\nexcepttion: something wrong\n")
                    return "hi"
            elif (message["sender"]["id"] == "2258111374248137"):  # felix trying, find your id in AWS dynamodb table item
                try:
                    bot_handler.handle_message(message)
                except:
                    print("\nexcepttion: something wrong\n")
                    return "hi"
            else:
                try:
                    bot_handler.handle_message(message)
                except:
                    print("\nexcepttion: something wrong\n")
                    return "Hi"
    return "Hi"


if __name__ == '__main__':
    # context = ('ssl/fullchain.pem', 'ssl/privkey.pem')
    app.run(host='0.0.0.0', debug=True)
