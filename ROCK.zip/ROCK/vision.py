#!/usr/bin/python
# -*- coding: utf-8 -*-

import io
import os

# Imports the Google Cloud client library
from google.cloud import vision

# Instantiates a client
client = vision.ImageAnnotatorClient()

def keras_bike_predict(bicycle, bicycle_wheel, bicycle_part, bicycle_frame, bicycle_tire, vehicle, spoke, bicycle_saddle, bicycle_fork, bicycle_drivetrain_part):
    from keras.models import load_model
    import numpy as np
    import pandas as pd
    from sklearn import preprocessing
    irisModel = load_model("vision/bike_model.h5")
    filepath="vision/BT3.xlsx"
    all_df = pd.read_excel(filepath)

    cols=['bicycle','bicycle_wheel','bicycle_part','bicycle_frame','bicycle_tire','vehicle','spoke','bicycle_saddle','bicycle_fork','bicycle_drivetrain_part','score']
    all_df=all_df[cols]
    
    train_df = all_df[:]


    ndarray = train_df.values
    b = np.array([[bicycle, bicycle_wheel, bicycle_part, bicycle_frame, bicycle_tire, vehicle, spoke, bicycle_saddle, bicycle_fork, bicycle_drivetrain_part]])
    Features = ndarray[:,:10]
    Features = np.concatenate((Features, b))
    leng = len(Features)

    minmax_scale = preprocessing.MinMaxScaler(feature_range=(0, 1))
    scaledFeatures=minmax_scale.fit_transform(Features)    

    train_Features=scaledFeatures

    print(train_Features[leng-1])

    
    predict_request = train_Features[leng-1]
    predict_request = np.array([predict_request])
    y_pred = irisModel.predict_classes(predict_request)
    return y_pred[0]


#!/usr/bin/python
# -*- coding: utf-8 -*-

# Instantiates a client
def broken_bike_detection(uri):
    import requests
    with open('vision/bike1.jpg', 'wb') as handle:
            response = requests.get(uri, stream=True)

            if not response.ok:
                print (response)

            for block in response.iter_content(1024):
                if not block:
                    break

                handle.write(block)

    from google.cloud import vision
    from google.cloud.vision import types

    vision_client = vision.ImageAnnotatorClient()
    file_name = 'vision/bike1.jpg'

    with io.open(file_name,'rb') as image_file:
        content = image_file.read()
    image = types.Image(content=content)
    response = vision_client.label_detection(image=image)
    labels = response.label_annotations
    print('Labels:')
    
    bicycle = 0
    bicycle_wheel = 0
    bicycle_part = 0
    bicycle_frame = 0
    bicycle_tire = 0
    vehicle = 0
    spoke = 0
    bicycle_saddle = 0
    bicycle_fork = 0
    bicycle_drivetrain_part = 0

    for label in labels:
        print(label.description)
        if label.description.lower()=='bicycle':
            bicycle = label.score
            print('bicycle =',bicycle)
        if label.description.lower().find('bicycle wheel') >= 0:
            bicycle_wheel = label.score
            print('bicycle wheel =',bicycle_wheel)
        if label.description.lower().find('bicycle part') >= 0:
            bicycle_part = label.score
            print('bicycle part =',bicycle_part)
        if label.description.lower() == 'bicycle frame':
            bicycle_frame = label.score
            print('bicycle frame =',bicycle_frame)
        if label.description.lower() == 'bicycle tire':
            bicycle_tire = label.score
            print('bicycle tire =',bicycle_tire)
        if label.description.lower() == 'vehicle':
            vehicle = label.score
            print('vehicle =',vehicle)
        if label.description.lower() == 'spoke':
            spoke = label.score
            print('spoke =',spoke)
        if label.description.lower() == 'bicycle saddle':
            bicycle_saddle = label.score
            print('bicycle saddle =',bicycle_saddle)
        if label.description.lower() == 'bicycle fork':
            bicycle_fork = label.score
            print('bicycle fork =',bicycle_fork)
        if label.description.lower() == 'bicycle drivetrain part':
            bicycle_drivetrain_part = label.score
            print('bicycle drivetrain part =',bicycle_drivetrain_part)
    
    return bicycle, bicycle_wheel, bicycle_part, bicycle_frame, bicycle_tire, vehicle, spoke, bicycle_saddle, bicycle_fork, bicycle_drivetrain_part

# [START detect_labels_uri]
def detect_labels_uri(uri, keyword):
    
    bicycle, bicycle_wheel, bicycle_part, bicycle_frame, bicycle_tire, vehicle, spoke, bicycle_saddle, bicycle_fork, bicycle_drivetrain_part = broken_bike_detection(uri)
    
    score = keras_bike_predict(bicycle, bicycle_wheel, bicycle_part, bicycle_frame, bicycle_tire, vehicle, spoke, bicycle_saddle, bicycle_fork, bicycle_drivetrain_part)
    
    
    # Check if labels contain your keyword
    return score

# [END detect_labels_uri]

# TEST
# print('bike is bike?: ')
tf = detect_labels_uri('https://tredz.azureedge.net/prodimg/Frog-55-20w-2019-Kids-Bike_75473_1_Zoom.jpg', 'bicycle')
print(tf)
# print('cat: is bike?:')
# print(detect_labels_uri('https://news.nationalgeographic.com/content/dam/news/2018/05/17/you-can-train-your-cat/02-cat-training-NationalGeographic_1484324.ngsversion.1526587209178.adapt.1900.1.jpg', 'bicycle'))
    
    



