#!/usr/bin/python
# -*- coding: utf-8 -*-

import requests
from requests import utils
from flask import Flask, request
import json
import time
import math
import random
import datetime
import boto3
from boto3.dynamodb.conditions import Key, Attr
from botocore.exceptions import ClientError
import random
import vision.vision as vision
import predict.predict as predict
import email_reply.email_reply as email_reply
#import googlemaps
#from datetime import datetime

#gmaps = googlemaps.Client(key='AIzaSyBI4ALNfd_6bVXSPG2h1Z-WxRbu0kuOWZs')
mydb = boto3.resource('dynamodb')  # we use dynamodb in AWS to record the status of every user so  that the ChatBot is able to contiue the chat with them from time to time
tablevoiceone = mydb.Table('voiceone') # we use a table named 'voiceone' to do above works. sender id as the unique key.
tablereport = mydb.Table('bikereport') # this table is to save all report data from users.
tablereportbackup = mydb.Table('bikereportbackup') # this table is to save all report data from users.

# Token of the bot
with open('config.json', 'r') as f:  # this part is the same with any chatbot in the world
    config = json.load(f)
    print(config)
access_token = config['FACEBOOK']['ACCESS_TOKEN']
count=0

from pymessager.message import Messager, QuickReply, ContentType, ActionButton, ButtonType
client = Messager(config['FACEBOOK']['ACCESS_TOKEN'])

title0 = "Welcome to BikeR's project menu, I am E-Box, your digital assistant."

buttons0 = [
    ActionButton(ButtonType.POSTBACK, "Start Recycling", "Start Recycling"),
    ActionButton(ButtonType.POSTBACK, "Project info", "Project info"),
    ActionButton(ButtonType.POSTBACK, "My Stats", "My Stats"),
]

buttons1 = [
    ActionButton(ButtonType.POSTBACK, "To Menu", "To Menu"),
]

title2 = "BikeR is a pubic service project founded by a group of students in 2016, the our goal is to make the streets cleaner by reporting unused and broken bikes to the government's cleaning team. "

buttons2 = [
    ActionButton(ButtonType.POSTBACK, "broken bikes?", "broken bikes?"),
    ActionButton(ButtonType.POSTBACK, "recycling process", "recycling process"),
    ActionButton(ButtonType.POSTBACK, "feedback", "feedback")
]

buttons3 = [
    ActionButton(ButtonType.POSTBACK, "Change Name", "changename"),
    ActionButton(ButtonType.POSTBACK, "Change Phone Number", "changephone"),
]

buttons3a = [
    ActionButton(ButtonType.POSTBACK, "upload photos", "upload photos"),
    ActionButton(ButtonType.POSTBACK, "Change Name", "changename"),
    ActionButton(ButtonType.POSTBACK, "Change Phone Number", "changephone"),
]

buttons3b = [
    ActionButton(ButtonType.POSTBACK, "upload photos", "upload photos"),
]

buttons4 = [
    ActionButton(ButtonType.POSTBACK,"comfirm upload", "confirm"),
    ActionButton(ButtonType.POSTBACK,"To Menu", "To Menu")
]

buttons5 = [
    ActionButton(ButtonType.POSTBACK,"manual", "Manual"),
    ActionButton(ButtonType.POSTBACK,"To Menu", "To Menu")
]

buttons6 = [
    ActionButton(ButtonType.POSTBACK,"detail", "detail"),
    ActionButton(ButtonType.POSTBACK,"abandon", "abandon")
]

levelname = ["rookie", "slightly advanced rookie", "level 3 apprentice", "level 2 apprentice", "level 1 apprentice", "rank 9 priest", "rank 8 priest", "rank 7 priest", "rank 6 priest", "rank 5 priest", "rank 4 priest", "rank 3 mentor", "rank 2 mentor", "Chosen Priest", "elder", "High Priest", "legendary bard", "legendary mage", "illuminati follower", "illuminati priest", "illuminati"]

def hasNumbers(inputString):
    return any(char.isdigit() for char in inputString)

def handle_message(messaging_event):  # the entrance of the chatbot. this function will be excuted for every message the user send to chatbot.
#    print("checkpoint1")
    talkuser(messaging_event)  # call the function name 'talkuser' in below

def talkuser(messaging_event):
#    print ("checkpoint2")
    recipient_id = messaging_event["sender"]["id"] #get user's unique ID to response to 
    resp = tablevoiceone.get_item(Key={'sender_idz':recipient_id}) #get the item values from dynamodb with the user's ID
    if (len(resp)<2):  #if there is no any item matchs the user's ID, means this is a new user for the fanpage messenger 
        tablevoiceone.put_item(Item={'sender_idz':recipient_id,'namez':"<empty>",'pnum':"<empty>",'switch':0,'picture':0,'correct':-1,'newclient':1,'credit':"0.0", 'totalz':0,'consecution':0,'localz':0,'score':0})  #create a new item with default value
    resp = tablevoiceone.get_item(Key={'sender_idz':recipient_id}) #get user info by id from the cloud database
    item = resp['Item'] #arange the list 'item' with the data in database for this user
    switch = item["switch"] #get 'switch' value. It descript the status of the user, for example switch=7 means the user is giving feedback to us
#    print ("checkpoint3")
    if "postback" in messaging_event:   #In the case that the user send a postback, a special type of message. Postback is button clicked.
        payloadtx = messaging_event["postback"]["title"] #recognize response and arrange it to the valiable 'payloadtx'
        if payloadtx == "開始使用" or payloadtx== "Get Started" or payloadtx == "To Menu" or payloadtx =="To Menu": # in case that the user go to the entrance of the conversation
#            print ("test")
            client.send_image(recipient_id,"https://scontent.ftpe12-1.fna.fbcdn.net/v/t1.0-9/60502088_868260083527412_4497744968470757376_n.png?_nc_cat=103&_nc_ht=scontent.ftpe12-1.fna&oh=33c77713dcab51e5e26f307cf3eae86e&oe=5D54CF9A") #send symbolic image of the initiative
            client.send_buttons(recipient_id, title0, buttons0) #send text and buttons to welcome new user
            tablevoiceone.update_item(Key={'sender_idz': recipient_id},UpdateExpression="set switch = :a",ExpressionAttributeValues={':a': 0}) #update user status to entrance         
        elif payloadtx == "Project info": #if the user wants to know more about the initiative
            client.send_image(recipient_id,"https://scontent.ftpe11-1.fna.fbcdn.net/v/t1.0-9/17098550_411276342559124_9132392283706263628_n.jpg?_nc_cat=102&_nc_ht=scontent.ftpe11-1.fna&oh=11a9282d5435406de6c16aa95aa4bb6c&oe=5D35274D") #send symbolic image of the initiative
            client.send_buttons(recipient_id, title2, buttons2) #send event info and more buttons to link to other info
            tablevoiceone.update_item(Key={'sender_idz': recipient_id},UpdateExpression="set switch = :a",ExpressionAttributeValues={':a': 0}) #update user status to entrance        
        elif payloadtx == "broken bikes?": #if the user wants to know more about the criteria of broken bike to be recycled.
            client.send_image(recipient_id,"https://scontent.ftpe11-1.fna.fbcdn.net/v/t1.0-9/16806647_402936603393098_4996495945397619203_n.jpg?_nc_cat=102&_nc_ht=scontent.ftpe11-1.fna&oh=54f2057f010f3672d14683897c455681&oe=5D3486C0") #send an image of broken bike
            client.send_buttons(recipient_id, "If a bike has lost parts or is extremely rusted or in other ways unusible, it is ready to be recycled", buttons2) #send info and buttons
            tablevoiceone.update_item(Key={'sender_idz': recipient_id},UpdateExpression="set switch = :a",ExpressionAttributeValues={':a': 0}) #update user status to entrance        
        elif payloadtx == "recycling process": # wants to know the process of recycling broken bike.
            client.send_image(recipient_id,"http://recycle.epb.taichung.gov.tw/sweep/images/img_sale-09.gif") #send an image 
            client.send_buttons(recipient_id, "Bike recycling process:after the cleaning team gets a report, they will investigate the case in three days, if it is acceptible for recycling, they will stick an note on the bike, if the note is still there after a week, the bike will be put in a shed, the picture of the bike will be put on a website, if the owner does not claim it, the bike will then be recycled.", buttons2) #send info and buttons
            tablevoiceone.update_item(Key={'sender_idz': recipient_id},UpdateExpression="set switch = :a",ExpressionAttributeValues={':a': 0}) #update status to entrance        
        elif payloadtx == "feedback": # to send feedback to us
            client.send_buttons(recipient_id, "we respect your opinion, please right down your ideas or problems here. \n\n If you don't want to write anything, you can click the button below to go to menu.", buttons1) #send message and button
            tablevoiceone.update_item(Key={'sender_idz': recipient_id},UpdateExpression="set switch = :a",ExpressionAttributeValues={':a': 7}) #set status to typing        
        elif payloadtx == "Change Name": # to change user's name
            client.send_buttons(recipient_id, "Please write the name you want us to know you by below. \n\n if you don't want to change your ID, you can press the button below to go to menu", buttons1) #send message and button
            tablevoiceone.update_item(Key={'sender_idz': recipient_id},UpdateExpression="set switch = :a",ExpressionAttributeValues={':a': 1}) #set status to typing        
        elif payloadtx == "Change Phone Number": # to change user's phone number
            client.send_buttons(recipient_id, "Please write down your phone number. \n\n If you don't want to change your number, press the button below to go to menu", buttons1) #send message to typing
            tablevoiceone.update_item(Key={'sender_idz': recipient_id},UpdateExpression="set switch = :a",ExpressionAttributeValues={':a': 2}) #set status to typing        
        elif payloadtx == "My Stats": # to show user's achievements
            ilv = round(float(item['credit']))+min(int(item['totalz']),50)//5 
            client.send_buttons(recipient_id,"User ID:"+item['namez']+"\n contact number:"+item['pnum']+"\n credit："+str(round(float(item['credit'])) )+"\n your level is: ["+ levelname[ilv]+"]\n you have reported "+str(item['totalz'])+"bikes. \n You have recycled 0 bikes.\n not recyled bikes:"+str(item['totalz'])+"\n these are your reports.", buttons1) #give status report
            tablevoiceone.update_item(Key={'sender_idz': recipient_id},UpdateExpression="set switch = :a",ExpressionAttributeValues={':a': 0}) #set status to entrance and update the total report number        
            resp1 = tablereport.query(KeyConditionExpression=Key('sender_idz').eq(recipient_id)) #get the reported item values from dynamodb 'bikereport' with the user's ID
            for i in resp1['Items']:
                client.send_buttons(recipient_id,"date:"+i['timestampz'][0:10]+"\n location:"+i['address']+"\n status report:"+i['status'],[ActionButton(ButtonType.POSTBACK,"detail", i['timestampz']),ActionButton(ButtonType.POSTBACK,"abandon", i['timestampz'])])
        elif payloadtx == "detail":
            resp1 = tablereport.query(KeyConditionExpression=Key('sender_idz').eq(recipient_id) & Key('timestampz').eq(messaging_event["postback"]["payload"])) #get the reported item values from dynamodb 'bikereport' with the item ID matching with timestampz field
            for i in resp1['Items']:
                client.send_image(recipient_id,i['bikephoto']) #send an image 
                client.send_buttons(recipient_id,"User ID:"+i['namez']+"\n contact number:"+i['pnum']+"\n date:"+i['timestampz'][0:10]+"\n address:"+i['address']+"\n :"+i['status']+"\n Next update:"+i['updatedate'][0:10],[ActionButton(ButtonType.POSTBACK,"abandon", i['timestampz'])])
        elif payloadtx == "abandon":
            resp1 = tablereport.query(KeyConditionExpression=Key('sender_idz').eq(recipient_id) & Key('timestampz').eq(messaging_event["postback"]["payload"])) #get the reported item values from dynamodb 'bikereport' with the item ID matching with timestampz field
            for i in resp1['Items']:
                client.send_buttons(recipient_id,"Abandon report?",[ActionButton(ButtonType.POSTBACK,"comfirm", i['timestampz']),ActionButton(ButtonType.POSTBACK, "To Menu", "To Menu")])
        elif payloadtx == "comfirm":
            resp1 = tablereport.query(KeyConditionExpression=Key('sender_idz').eq(recipient_id) & Key('timestampz').eq(messaging_event["postback"]["payload"])) #get the reported item values from dynamodb 'bikereport' with the item ID matching with timestampz field
            for i in resp1['Items']:
                tablereportbackup.put_item(Item=i)  #copy a record from bikereport table to bikereportbackup table for backup purpose before deleting it 
            tablereport.delete_item(Key={'sender_idz': recipient_id, 'timestampz': messaging_event["postback"]["payload"]})  # delete it from bikereport table
            tablevoiceone.update_item(Key={'sender_idz': recipient_id},UpdateExpression="set switch = :a, totalz = :b",ExpressionAttributeValues={':a': 0, ':b': int(item['totalz'])-1}) #set status to entrance and update the total report number        
            client.send_buttons(recipient_id,"Report deleted successfully", buttons1) 
        elif payloadtx == "Start Recycling": # to start to report a broken bike
            if item['namez']=='<empty>' or item['pnum']=='<empty>': #if either usermane or phone number is not provided 
                client.send_buttons(recipient_id, "The cleaning team requires you to provide your real name and number. \n\n User ID:"+item['namez']+"\n contact number:"+item['pnum'], buttons3) #ask for name and number
            else: #existing number and name
                client.send_buttons(recipient_id, "Please send a photo of the bike/bikes you wish to report. \n\n user ID:"+item['namez']+"\n contact number:"+item['pnum'], buttons3a) # ask user to send image of broken bike 
            tablevoiceone.update_item(Key={'sender_idz': recipient_id},UpdateExpression="set switch = :a",ExpressionAttributeValues={':a': 3}) #send photo        
        elif payloadtx == "upload photos": # to upload an image of broken bike
            client.send_text(recipient_id,"Please send a photo of the bike/bikes you wish to report.") #ask for photo
            tablevoiceone.update_item(Key={'sender_idz': recipient_id},UpdateExpression="set switch = :a",ExpressionAttributeValues={':a': 4}) #send photo        
        elif switch==6 and (payloadtx == "comfirm" or payloadtx == "Manual"): # to confirm reporting
            final = float(int(item['score']) + float(item['credit'])*int(item["totalz"]))/(int(item["totalz"])+1) #recalculate credit score including the score of new report
            if payloadtx == "comfirm": # if the report was recognized by AI as a high score one and the user confirmed to sumbit.
                email_reply.send_email("dfctw2017@gmail.com","<BikeR> User report:", "Dear sir/madam, \n\n This is a report from one of <BikeR>'s users. The report has already been authenticated and is likely correct. Please send workers to the address. \n\n report info: \n User ID: "+item['namez']+"\n contact number: "+item['pnum']+"\n address: "+item['email']+item['address']+"\n photo: "+item['urlz']+"\n\n AI score:  "+str(item['score'])+" points(out of 10)\n\n Thank you for your cooperation. \n\n from, \n <BikeR> volenteers") #send email
                client.send_text(recipient_id,"The report has been sent, in about a week, the cleaning team will come to check on the bike. ") #respond confirmation
            else:  # payloadtx == "manual"  # if this is a report with low score and the user is still keen to sumbit it.
                email_reply.send_email("dfctw2017@gmail.com","Manual processing request: <BikeR>'s User report", "Dear sir/madam, \n\n This is a project report from <BikeR>'s Users, our AI thought the report was invalid, however, the user insists that it is correct and requests manual processing. \n\n repot info: \n User ID: "+item['namez']+"\n contact number: "+item['pnum']+"\naddress: "+item['email']+item['address']+"\n photo: "+item['urlz']+"\n\n AI score: "+str(item['score'])+" points(out of 10)\n\n Thank you for your cooperation. \n\n from, \n <BikeR> volenteers") #send email
                client.send_text(recipient_id,"The report has been sent to <BikeR>'s volemteers, if it is valid, the report will still be sent. in about a week, the clean team will go and check on it.")                
            tablevoiceone.update_item(Key={'sender_idz': recipient_id},UpdateExpression="set switch = :a, score = :b, credit = :c, totalz = :d, picture = :e, correct = :f, newclient = :g, consecution = :h, localz = :i",ExpressionAttributeValues={':a': 0, ':b':0, ':c':str(final), ':d':int(item["totalz"])+1, ':e':0, ':f':-1, ':g':0, ':h':0, ':i':0 }) #reset status        
            tablereport.put_item(Item={'rid':int(time.mktime(datetime.datetime.now().timetuple())),'timestampz':str(datetime.datetime.now()), 'sender_idz':recipient_id,'namez':item['namez'],'pnum':item['pnum'],'bikephoto':item['urlz'], 'cityz':item['email'], 'address':item['address'], 'score': item['score'], 'latz': item['latz'], 'longz': item['longz'], 'status':"已舉報", 'handler':"未指派", 'updatedate':str(datetime.datetime.now())})  #create a new item with default value
            client.send_buttons(recipient_id, title0, buttons0) #send entrance buttons
        else:
            client.send_buttons(recipient_id, "i do not understand your message.\n\n"+title0, buttons0) #send response to those postback button that is not pre-designed.
            tablevoiceone.update_item(Key={'sender_idz': recipient_id},UpdateExpression="set switch = :a",ExpressionAttributeValues={':a': 0}) #set status to entrance        
    elif "message" in messaging_event and "text" in messaging_event["message"]:   #In the case that the user send a text message
        text = messaging_event["message"]["text"] #put sent text into the valiable 'text'
        if switch == 7: #if user is sending feedbacks to us
            email_reply.send_email("dfctw2017@gmail.com","<BikeR> user feedback", "dear sir/madam\n\n this is one of <BikeR>'s user's feedback report.please foward this to the volenteers to be analyzed and discussed\n\n user ID:"+str(item['namez'])+"\n contact number:"+str(item['pnum'])+"\n feedback:\n-----------\n"+text+"\n-----------\n\n from, \n E-Box  \n\n P.S. do not respond") #send an email with proper content to the operation team
            client.send_text(recipient_id,"good! the message is sent.") #send text response to user
            tablevoiceone.update_item(Key={'sender_idz': recipient_id},UpdateExpression="set switch = :a",ExpressionAttributeValues={':a': 0}) #status:　entrance        
            client.send_buttons(recipient_id, title0, buttons0) #send entrance buttons
        elif switch == 1: #change name
            tablevoiceone.update_item(Key={'sender_idz': recipient_id},UpdateExpression="set switch = :a, namez=:b",ExpressionAttributeValues={':a': 0, ':b':text})         
            item['namez'] = text
            if item['namez']=='<empty>' or item['pnum']=='<empty>':
                client.send_buttons(recipient_id, "you need to give your name and number to the cleaning team in order to report bikes.\n\n User ID:"+item['namez']+"\n contact number:"+item['pnum'], buttons3)
            else:
                client.send_buttons(recipient_id, "please send a photo of the bike/bikes you want to report.\n\n User ID:"+item['namez']+"\n contact number:"+item['pnum'], buttons3a)
            tablevoiceone.update_item(Key={'sender_idz': recipient_id},UpdateExpression="set switch = :a",ExpressionAttributeValues={':a': 3})         
        elif switch == 2: #change phone
            tablevoiceone.update_item(Key={'sender_idz': recipient_id},UpdateExpression="set switch = :a, pnum = :b",ExpressionAttributeValues={':a': 0, ':b':text})         
            item['pnum'] = text
            if item['namez']=='<empty>' or item['pnum']=='<empty>':
                client.send_buttons(recipient_id, "you need to give your name and number to the cleaning team in order to report bikes.\n\n User ID:"+item['namez']+"\n contact number:"+item['pnum'], buttons3)
            else:
                client.send_buttons(recipient_id, "please send a photo of the bike/bikes you want to report.\n\n舉報聯絡人:"+item['namez']+"\n聯絡電話:"+item['pnum'], buttons3a)
            tablevoiceone.update_item(Key={'sender_idz': recipient_id},UpdateExpression="set switch = :a",ExpressionAttributeValues={':a': 3})         
        else:
            client.send_buttons(recipient_id, "??????\n\n"+title0, buttons0)
            tablevoiceone.update_item(Key={'sender_idz': recipient_id},UpdateExpression="set switch = :a",ExpressionAttributeValues={':a': 0}) #status: entrance        
    else:
        for attachment in messaging_event["message"]["attachments"]: #if message has attatchments
            if (attachment["type"] == "image") and (switch==4 or switch==5): #if attachment is image
                tablevoiceone.update_item(Key={'sender_idz': recipient_id},UpdateExpression="set picture = :a",ExpressionAttributeValues={':a': 1}) #status: photo
                client.send_text(recipient_id,"photo received, identifying...")
                url = attachment["payload"]["url"] #initualize url
                ans = vision.detect_labels_uri(url,"bicycle") #send to google vision api for diagnosis
                tablevoiceone.update_item(Key={'sender_idz': recipient_id},UpdateExpression="set urlz = :a",ExpressionAttributeValues={':a': url})
                if str(ans)=="True":
                    tablevoiceone.update_item(Key={'sender_idz': recipient_id},UpdateExpression="set correct = :a, switch=:b",ExpressionAttributeValues={':a': 1, ':b':5}) #set status to sending photo
                    client.send_text(recipient_id,"bike identified.") #send message to tell that AI has recognized a bike in the photo
                else:
                    tablevoiceone.update_item(Key={'sender_idz': recipient_id},UpdateExpression="set correct = :a, switch=:b",ExpressionAttributeValues={':a': 0, ':b':5}) #set status to sending photo
                    client.send_buttons(recipient_id, "哎呀! 小智看不出來腳踏車，請重新拍攝上傳看看喔!", buttons3b) # ask user to resend image of broken bike 
                    client.send_text(recipient_id,"如果您確定照片是對的，那就請你提供它的位置喔!")#send message to tell that AI can not find any bike in the photo.
                client.send_quick_replies(recipient_id,"請告訴我廢棄腳踏車的所在地",[QuickReply("位置", "位置",None,ContentType.LOCATION)]) #ask for location of the broken bike
            elif (attachment["type"] == "location") and (switch==5): #if attachment is location
                latz = attachment["payload"]["coordinates"]["lat"]
                longz = attachment["payload"]["coordinates"]["long"]
                georesult = requests.get(url = "http://api.opencube.tw/location", params = {'lat':str(latz), 'lng':str(longz), 'key':"AIzaSyBI4ALNfd_6bVXSPG2h1Z-WxRbu0kuOWZs"}) 
                geojson = georesult.json()
                client.send_text(recipient_id,"the address you gave me is:"+geojson['data']['full_address'])
                if geojson['data']['country']=="TW": # if it is a location within Taiwan
                    intaiwan = 1
                else:
                    intaiwan = 0    
                name = item['namez']
                phone = item['pnum']
                addr = geojson['data']['full_address']
                client.send_text(recipient_id,"address received, E-Box is grading your report.")
                score = predict.keras_predict(int(item['picture']), int(item['correct']), int(item['newclient']), float(item["credit"]), int(item['totalz']), int(item["consecution"]), int(intaiwan))
                if (len(addr)<5 or len(addr)>30):  # to discount the score if the address is too short or too long, this is a turn around be we re-train the AI
                    score = round(score * 0.7)
                if ("路" not in addr) and ("街" not in addr) and ("號" not in addr): # as above, discount if the address doesn't contain any important keyword
                    score = round(score * 0.5) 
                tablevoiceone.update_item(Key={'sender_idz': recipient_id},UpdateExpression="set switch = :a, score=:b, address=:c, email=:d, localz=:e, latz=:f, longz=:g",ExpressionAttributeValues={':a': 6, ':b':int(score), ':c':addr, ':d':geojson['data']['city'], ':e':int(intaiwan), ':f':str(latz), ':g':str(longz)})         
                if score >= 7:
                    client.send_buttons(recipient_id, "Great! you got "+str(score)+"points! \n report content:\n User ID"+str(name)+"\n contact number:"+str(phone)+"\n address:"+addr, buttons4) #send if enough points
                else:
                    client.send_buttons(recipient_id, "your report only got "+str(score)+"points. \n would you still like to submit this report?", buttons5) #ask to send if not enough points
            else: #if don't understand response. It means that the user sent a unexpected response to Chatbot.
                tablevoiceone.update_item(Key={'sender_idz': recipient_id},UpdateExpression="set switch = :a",ExpressionAttributeValues={':a': 0}) 
                client.send_buttons(recipient_id, "E-Box does not understand your response...\n\n"+title0, buttons0) #send message
